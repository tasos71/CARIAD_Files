# Bypass SSL certificate validation
Add-Type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
    public bool CheckValidationResult(
        ServicePoint srvPoint, X509Certificate certificate,
        WebRequest request, int certificateProblem) {
        return true;
    }
}
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy

# Get the IP addresses from environment variables
$primaryServerIp = $env:PRIMARY_SERVER_IP
$replicaServerIp = $env:REPLICA_SERVER_IP

# Function to promote replica to primary
function Promote-Replica {
    Write-Output "Promoting replica to primary..."
    # promotion logic
    .\Task1Script\promote_replica.ps1
}

# Function to switch back to original primary
function Switch-Back-To-Primary {
    Write-Output "Switching back to original primary..."
    # switch back logic
    .\Task1Script\switch_back_to_primary.ps1
}

# Check if the primary server is up
if (-not (Test-Connection -ComputerName $primaryServerIp -Count 3 -Quiet)) {
    Write-Output "Primary server is down. Promoting replica..."
    Promote-Replica
    exit 0
}

# Check if essential services are running
$services = @("nginx", "mysql", "redis", "elasticsearch")
foreach ($service in $services) {
    if (-not (Get-Service -Name $service -ErrorAction SilentlyContinue).Status -eq 'Running') {
        Write-Output "$service is not running. Promoting replica..."
        Promote-Replica
        exit 0
    }
}

# Check the health endpoint of the primary server
$primaryUrl = "https://techtaskwp05ghes-ghe.westeurope.cloudapp.azure.com/health"
$replicaUrl = "https://replicatewp05ghes-ghe.eastus.cloudapp.azure.com/health"
$response = Invoke-WebRequest -Uri $primaryUrl -UseBasicParsing

if ($response.StatusCode -ne 200) {
    Write-Output "Primary server health check failed. Promoting replica..."
    Promote-Replica
} else {
    Write-Output "Primary server is healthy"
    # Check if the replica is currently the primary
    $replicaResponse = Invoke-WebRequest -Uri $replicaUrl -UseBasicParsing
    if ($replicaResponse.StatusCode -eq 200) {
        Write-Output "Replica is currently primary. Switching back to original primary..."
        Switch-Back-To-Primary
    }
}

Write-Output "Health check completed."
