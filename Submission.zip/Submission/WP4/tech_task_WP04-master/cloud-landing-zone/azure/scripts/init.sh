#!/bin/bash
sudo apt-get update
sudo apt-get install -y nginx
sudo apt-get install -y python2
sudo update-alternatives --remove-all python
sudo update-alternatives --install /usr/bin/python python /usr/bin/python2 1
