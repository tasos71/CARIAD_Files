import os
import time
import requests
from azure.monitor.opentelemetry import AzureMonitorTraceExporter
from azure.identity import DefaultAzureCredential
from azure.monitor import MetricsClient

# Azure Monitor credentials
credential = DefaultAzureCredential()
metrics_client = MetricsClient(credential)

# Azure Monitor metrics push function
def push_metrics_to_azure_monitor(upload_speed, download_speed):
    # Push upload speed
    metrics_client.create_metric(
        namespace='CustomMetrics',
        name='WebServiceUploadSpeed',
        value=upload_speed,
        dimensions={'Endpoint': 'your_endpoint_name', 'Measurement': 'Upload'}
    )

    # Push download speed
    metrics_client.create_metric(
        namespace='CustomMetrics',
        name='WebServiceDownloadSpeed',
        value=download_speed,
        dimensions={'Endpoint': 'your_endpoint_name', 'Measurement': 'Download'}
    )

# Function to measure upload speed
def measure_upload_speed(url, file_path):
    start_time = time.time()
    with open(file_path, 'rb') as f:
        requests.post(url, files={'file': f})
    elapsed_time = time.time() - start_time
    file_size = os.path.getsize(file_path) * 8  # in bits
    upload_speed = file_size / elapsed_time  # bits per second
    return upload_speed

# Function to measure download speed
def measure_download_speed(url):
    start_time = time.time()
    response = requests.get(url)
    elapsed_time = time.time() - start_time
    file_size = len(response.content) * 8  # in bits
    download_speed = file_size / elapsed_time  # bits per second
    return download_speed

# Your endpoint URLs
upload_url = 'https://your-web-service/upload'
download_url = 'https://your-web-service/download'

# Main loop for continuous measurement
while True:
    # Measure speeds
    upload_speed = measure_upload_speed(upload_url, 'test_file.txt')
    download_speed = measure_download_speed(download_url)

    # Push metrics to Azure Monitor
    push_metrics_to_azure_monitor(upload_speed, download_speed)

    # Sleep for a defined interval (e.g., 60 seconds)
    time.sleep(60)
