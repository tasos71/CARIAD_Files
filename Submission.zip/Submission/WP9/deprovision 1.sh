#!/bin/bash

# Deprovision the Azure agent
sudo waagent -deprovision+user -force && export HISTSIZE=0 && sync
sudo apt-get remove -y walinuxagent
sudo rm -rf /var/lib/waagent
sudo rm -rf /etc/waagent.conf
sudo rm -rf /var/log/waagent.log

# Ensure this script runs only once
sudo rm -f /etc/rc.local
