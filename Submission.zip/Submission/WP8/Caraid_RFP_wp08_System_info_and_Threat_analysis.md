# CARIAD EngIT Frame – tech task–WP08/8a – IT Sec cons

**Section A**:

**Understanding the System and Components**

This document provides a detailed analysis of the GitHub Enterprise
Server architecture based on the provided architecture diagram and text.
The architecture is built in a CI/CD environment on Azure and comprises
multiple components including a GitHub Enterprise Server installed on an
Azure VM, two organizations (User Account Organization and LearningLab
Organization), a Node.js application running within an OCP-NODE, and
interactions between these components.

Assumptions:

1.  The system uses GitHub Enterprise Server installed on a VM in Azure,
    considering the mention of SUBNET-4.

2.  The OpenShift container platform (OCP) is also built on Azure which
    hosts PODs and docker container where the NodeJS App is built and
    deployed for use.

3.  GitHub App has access to all repositories in LearningLab and User
    Account organization.
![[media-wp08/image3.png]]

# 1. GitHub Enterprise Server

The GitHub Enterprise Server in this architecture is installed on an
Azure Virtual Machine (VM) within a designated subnet named SUBNET-4.
The environment is a CI/CD pipeline in Azure, which allows for
continuous integration and delivery processes, ensuring automated
deployment and updates. The GitHub Enterprise account is configured to
manage two organizations: the 'User Account Organization' and the
'LearningLab Organization.' SUBNET-4 provides network isolation and
allows secure interactions between the GitHub Enterprise Server, users,
and other components in the Azure environment.

# 2. Organizations in GitHub Enterprise Server

The architecture includes two organizations within the GitHub Enterprise
Server: 1) User Account Organization and 2) LearningLab Organization
.These organizations serve different purposes and interact with each
other through repositories and events.

The User Account Organization is where individual users or actors
interact with their own GitHub repositories, typically learning
repositories. These repositories are forked versions of the Template
Repository housed within the LearningLab Organization.

The LearningLab Organization contains a Template Repository which serves
as the foundational repository that can be forked or copied by users
into their own Learning Repository. The LearningLab Organization also
contains a GitHub App that facilitates interactions between the
organizations and tracks events and user activities.

# 3. GitHub App in LearningLab Organization

The GitHub App within the LearningLab Organization is a crucial
component of this architecture. This app is granted access to all
repositories in both organizations (User Account Organization and
LearningLab Organization), allowing it to track and manage interactions
between repositories.

The app facilitates user authentication through OAuth and uses the
GitHub REST API to perform various actions such as creating
repositories, managing branches, and handling repository events. When a
user logs into GitHub Enterprise, they can install this GitHub App
within their User Account Organization. The app is responsible for
monitoring events, such as when a user forks or updates a Learning
Repository from the Template Repository. The app then records these
activities and logs it in the LearningLab Organization

# 4. Event Monitoring and User Repository Management

The architecture is designed to track and respond to repository events.
The GitHub App plays a key role here, monitoring actions such as
commits, pull requests, and forks in the User Account Organization. Each
user has their own User Instance within the GitHub Enterprise Server
where they manage their Learning Repository (a fork of the Template
Repository from the LearningLab Organization). When a user creates or
updates their repository, the app records the events and can trigger
automated actions, such as synchronization or feedback mechanisms.

# 5. Node.js Application in OCP-NODE

At the bottom layer of the architecture, a Node.js application is
running in an **OpenShift Container Platform (OCP) node**, specifically
in the LearningLab Namespace. This application is deployed within a
Docker container in the LearningLab POD, using technologies such as
**Express.js, Log4js, Handlebars, and Octokit**.

The Node.js app interacts with the GitHub Enterprise specifically with
GitHubApp using REST API over HTTPS (port 443). Using Octokit, the
Node.js app communicates with the GitHub App within the LearningLab
Organization, allowing it to perform various actions related to NodeJS
App management. For example, the app could track NodeJS App events,
build status, issues.

# 6. Interactions Between Components

The architecture facilitates seamless interactions between the various
components: - The GitHub Enterprise Server manages two organizations,
where users interact with repositories.- The Node.js app in the OCP-NODE
uses Octokit to interact with the GitHub Enterprise Server, performing
tasks like repository management and event tracking.- The GitHub App in
the LearningLab Organization tracks user events, manages repository
updates, and ensures that users can seamlessly fork and work on the
templates provided by the LearningLab.

**Section B :**

**Storage Points for confidential and PII information:**

1.  GitHub Enterprise Organizations

    1.  **Confidential Data/PII**: These repository can contain
        user-specific information, project files, and potentially user
        submissions with PII (e.g., names, email addresses).

2.  GitHub App(LearningLab Organization)

    1.  **Confidential Data**: This app could have access tokens, OAuth
        credentials, or API keys to communicate with repositories,
        Private Keys.

3.  NodeJS App

    1.  **Confidential Data/PII**: The NodeJS app may handle or
        temporarily store user requests, responses, and progress data,
        which could include PII (e.g., usernames, session data)

4.  Log4js

    1.  **Confidential Data/PII**: Logs may accidentally store user
        details like usernames, user information, IP addresses, or even
        API keys depending on the logging configuration.

**Section C :**

**Data Flow Diagrams with Trust Boundaries**
![[media-wp08/fbecaf728c58cfec136acd3ece498a153fd983ab.png]]

| **Trust Boundary**                                                    | **Description**                                                                                                                                         | **Potential Threats**                                                              |
| --------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------- |
| TB01-<br><br>Actor → GitHub Enteprise (UI 443)                        | Boundary where the external Actor (User) interacts with the GitHub Enterprise Server deployed on the Azure via a secure HTTPS connection.               | Spoofing, Tampering, Repudiation, Information Disclosure, Man-in-the-Middle        |
| TB02 –<br><br>Actor → Node.js App (UI 443)                            | Boundary where the external Actor (User) interacts with the Node.js app deployed on the OCP-NODE via a secure HTTPS connection.                         | Spoofing, Tampering, Repudiation, Information Disclosure, Man-in-the-Middle        |
| TB03-<br><br>Node.js App → GitHub Enterprise                          | Secure communication (HTTPS port 443) between the Node.js app and GitHub APP involving Octokit for API calls.                                           | Man-in-the-Middle, Unauthorized API Access, Data Tampering, Information Disclosure |
| TB04-<br><br>GitHub App → GitHub Enterprise User Account Organization | GitHub App in LearningLab Organization with access to both organizations and their repositories, managing repository events and actions.                | App Misuse, Data Exposure, Tampering, Information Disclosure                       |
| TB05-<br><br>User Instance → Learning Repository                      | Boundary where a user accesses their Learning Repository (a fork of the Template Repository) in the User Account Organization within GitHub Enterprise. | Tampering, Unauthorized Access, Data Synchronization Issues                        |


**STRIDELM Threat Model Analysis**

|**STRIDELM Category**|**Threat**|**Description**|**Mitigations**|**Trust Boundary**|
| --- | --- | --- | --- | --- |
|Spoofing|Impersonation of legitimate users|An attacker could impersonate a legitimate user (Actor) to access the Node.js app or GitHub Enterprise Server.|- Implement OAuth for authentication.<br><br>- Use MFA for all user logins.<br><br>- Ensure session management and timeout features are in place.|TB01|
||Impersonation of GitHub App|An attacker could impersonate the GitHub App to access repositories or events in GitHub Enterprise Server.|- Use **OAuth tokens** with limited scope for the GitHub App.  <br>- Regularly review GitHub App permissions.|TB04|
|Tampering|Modification of repositories|An attacker could modify repositories (Learning Repository or Template Repository), injecting malicious code.|- Use **signed commits** and **branch protection rules**.  <br>- Enforce **code reviews** before merging changes.|TB05|
||Tampering with API communications|An attacker could alter API requests between the Node.js app and GitHub App.|- Ensure **HTTPS (TLS/SSL)** is enforced for all communications.  <br>- Use **API security** with OAuth tokens for authentication.|TB03|
|Repudiation|Denying actions performed on repositories|A malicious actor could deny having made changes to a repository or accessing specific data without proper logging.|- Enable **GitHub audit logs** for tracking all repository changes.  <br>- Implement **centralized logging** in the Node.js app to track user actions|TB05|
|Information Disclosure|Sensitive data exposure during communication|Unencrypted communication between the Node.js app and GitHub Enterprise could lead to sensitive information being intercepted.|- Enforce **HTTPS** for all communication channels (UI 443 and REST API requests).  <br>- Use **end-to-end encryption** for sensitive data like credentials and tokens.|TB01, TB02, TB03|
||Repository data leakage|An attacker could gain unauthorized access to repositories containing sensitive or proprietary information.|- Implement **RBAC** to limit repository access.|TB04,TB05|
|Denial of Service|Overloading the Node.js app or GitHub Enterprise Server|An attacker could send excessive traffic to the Node.js app or GitHub Enterprise Server, causing resource exhaustion and service disruption.|- Implement **rate limiting** and **traffic throttling**.  <br>- Enable **auto-scaling** for the Node.js app in OpenShift to handle traffic spikes.|TB01,TB02|
|Elevation of Privilege|Privilege escalation in GitHub Enterprise or Node.js app|A user or attacker could exploit vulnerabilities to gain unauthorized administrative access to repositories or system components.|- Apply **least privilege** principles in access control.  <br>- Regularly update and patch GitHub Enterprise and the Node.js app.|TB04|
|Lateral Movement|Moving between systems in SUBNET-4 or OCP-NODE|Once a system (like the Node.js app) is compromised, an attacker could move laterally within OpenShift or GitHub Enterprise to gain access to other resources|- Use **OpenShift network policies** to restrict lateral movement.  <br>- Segment services within SUBNET-4 to isolate critical resources.|TB02|
|Man-in-the-Middle|Intercepting communication between Actor and Node.js app|An attacker could intercept the communication between the user (Actor) and the Node.js app, reading or modifying the data in transit.|- Enforce **TLS/SSL** for all communications.|TB01, TB02|

**Section D**:

**Derived Security requirements**

|**Category**|**Security Requirement**|**Description**|
|---|---|---|
|User Authentication|Multi-Factor Authentication (MFA)|Users must authenticate with MFA to provide an extra layer of security beyond passwords|
||OAuth 2.0 for Authentication|Use OAuth 2.0 for user authentication and authorization when accessing GitHub Enterprise and the Node.js app.|
||Role-Based Access Control (RBAC)|Implement RBAC to control user permissions and ensure least privilege access to resources.|
||Least Privilege Principle|Users should have access only to the minimum resources needed for their role.|
|Secure Communication|HTTPS (SSL/TLS) for All Communications|Ensure all communication between users, Node.js app, and GitHub Enterprise occurs over encrypted channels using HTTPS (port 443).|
||Mutual TLS (mTLS)|Use mutual TLS for internal service communication between the Node.js app and GitHub Enterprise Server.|
|Data Integrity|Signed Commits in GitHub|Require signed commits to verify the identity of contributors and ensure code integrity in repositories.|
||Branch Protection Rules|Use branch protection rules in GitHub to prevent unauthorized or unreviewed changes.|
||Input Validation|Implement strong input validation in the Node.js app to prevent injection attacks like XSS and SQL injection.|
|API Security|OAuth-Based API Access|Use OAuth tokens to secure API calls between the Node.js app and GitHub Enterprise, ensuring scoped access.|
||API Rate Limiting|Apply rate limiting to all API calls to prevent abuse and denial-of-service (DoS) attacks.|
||Token Expiry and Refresh|Use short-lived OAuth tokens with secure token refresh processes to prevent unauthorized API access.|
||Audit API Usage|Monitor and log API usage for all interactions between the Node.js app and GitHub Enterprise.|
|Logging & Auditing|Centralized Logging|Implement centralized logging for all key components, including the Node.js app and GitHub Enterprise, for security monitoring.|
||GitHub Audit Logs|Enable and monitor GitHub audit logs to track repository access and changes.|
||Event Monitoring and Alerts|Use monitoring tools to detect unusual activities or potential security incidents and trigger alerts.|
|GitHub Repository Security|GitHub Organization-Level Controls|Define access controls for both User Account Organization and LearningLab Organization to restrict repository access.|
||Granular Permissions for GitHub App|Ensure the GitHub App has the minimum required permissions to manage repositories and events.|
||Fork Synchronization Security|Control synchronization between forks and template repositories, ensuring secure updates and no unauthorized changes.|
|Data Confidentiality|Encryption of Sensitive Data|Ensure sensitive information is encrypted both in transit and at rest, particularly user data and personal information (PII).|
||Access Control to Repositories|Enforce strict access controls to repositories containing sensitive information.|
|Application Security|Container Security|Ensure the Docker container hosting the Node.js app is securely configured, with resource limits and no excessive privileges.|
||Application-Level Access Control|Implement fine-grained access controls within the Node.js app to limit user actions based on roles.|
|Network Security|Network Segmentation|Implement network segmentation between the OCP-NODE and SUBNET-4 to limit lateral movement in case of a security breach.|
||Firewall and Security Groups|Apply firewall rules and security groups to control traffic between segments and limit exposure to necessary services.|
|Resilience to DoS|Traffic Throttling and Rate Limiting|Implement traffic throttling and rate limiting to protect against denial-of-service (DoS) attacks.|
||Auto-Scaling in OpenShift|Enable auto-scaling for the Node.js app in OpenShift to handle legitimate traffic spikes and mitigate DoS risks.|

**Section E:**

**Mapping of NIST Controls to the Security Requirements**

|**Security Requirement**|**Description**|**NIST SP 800-53 Control & Description**|
|---|---|---|
|Multi-Factor Authentication (MFA)|Enforce MFA for all user logins to ensure that users authenticate with more than one factor.|IA-2 (Identification and Authentication): Requires multi-factor authentication for user access.|
|OAuth 2.0 for Authentication|Use OAuth 2.0 for secure authentication and access control to GitHub App and Node.js app.|AC-2 (Account Management): Ensures that systems implement access control and account management.|
|Role-Based Access Control (RBAC)|Implement role-based access control to enforce least privilege access to GitHub repositories and the Node.js app.|AC-3 (Access Enforcement): Enforces access control policies, including least privilege.|
|Least Privilege Principle|Ensure that users only have access to the resources necessary for their role.|AC-6 (Least Privilege): Limits the user access to the minimum necessary for their roles.|
|HTTPS (SSL/TLS) for All Communications|Encrypt all communications between users, Node.js app, and GitHub Enterprise with HTTPS to prevent eavesdropping.|SC-8 (Transmission Confidentiality and Integrity): Ensures the confidentiality and integrity of transmitted information through encryption.|
|Mutual TLS (mTLS)|Use mutual TLS for secure communication between internal services (Node.js app and GitHub App).|SC-12 (Cryptographic Key Establishment and Management): Manages cryptographic keys and TLS certificates for secure communication.|
|Signed Commits in GitHub|Require signed commits in GitHub repositories to verify the identity of contributors and protect against tampering.|SI-7 (Software, Firmware, and Information Integrity): Ensures integrity of software and data to prevent unauthorized changes.|
|Branch Protection Rules|Enforce branch protection rules to prevent unauthorized changes to code repositories.|CM-5 (Access Restrictions for Configuration Changes): Ensures that access to configuration settings is restricted and protected from unauthorized changes.|
|Input Validation|Implement strong input validation to prevent injection attacks like XSS and SQL injection in the Node.js app.|SI-10 (Information Input Validation): Ensures that input data is validated to prevent malicious actions.|
|OAuth-Based API Access|Secure API calls with OAuth tokens, ensuring that each API call is authenticated and authorized.|AC-2 (Account Management): Controls account management, ensuring only authorized users access APIs.|
|API Rate Limiting|Implement rate limiting to prevent abuse of API services and denial-of-service attacks.|SC-5 (Denial of Service Protection): Ensures protection against resource exhaustion attacks (DoS).|
|Token Expiry and Refresh|Use short-lived OAuth tokens with secure refresh to reduce the risk of token compromise.|IA-5 (Authenticator Management): Ensures secure management of authentication tokens and credentials.|
|Centralized Logging|Implement centralized logging for Node.js app and GitHub Enterprise to monitor security events.|AU-6 (Audit Monitoring, Analysis, and Reporting): Requires systems to monitor and report security events and activities.|
|Immutable Logs|Ensure that all logs are immutable and tamper-proof to provide a reliable audit trail.|AU-9 (Protection of Audit Information): Ensures that audit logs are protected from modification and tampering.|
|GitHub Audit Logs|Enable GitHub audit logs to track access to repositories and changes made by users.|AU-12 (Audit Generation): Requires systems to generate audit logs for user actions and access control.|
|Event Monitoring and Alerts|Use monitoring tools to detect security incidents and trigger alerts based on unusual activities.|CA-7 (Continuous Monitoring): Implements continuous monitoring and alerts for security-related incidents.|
|Granular Permissions for GitHub App|Ensure that the GitHub App has minimal permissions, scoped to specific tasks and repositories.|AC-2 (Account Management): Controls and limits account privileges to ensure least privilege access.|
|Encryption of Sensitive Data|Ensure that sensitive data is encrypted in transit and at rest to protect user information and credentials.|SC-13 (Cryptographic Protection): Ensures the encryption of data both at rest and during transmission.|
|Incident Detection and Response Plan|Establish incident detection and response procedures for handling security breaches and suspicious activities.|IR-4 (Incident Handling): Establishes procedures to detect, respond to, and recover from security incidents.|
|Data Backup and Recovery|Ensure regular backups of data and repositories, with tested recovery procedures in case of security incidents.|CP-9 (Information System Backup): Requires regular system backups and procedures for restoring data after an incident.|
|Network Segmentation|Implement network segmentation between the OCP-NODE and SUBNET-4 to limit lateral movement in the event of a breach.|SC-7 (Boundary Protection): Ensures the segregation of networks to protect against lateral movement within systems.|
|Firewall and Security Groups|Apply firewall rules and security groups to control traffic between different components, limiting access to necessary services.|SC-7 (Boundary Protection): Protects the network perimeter and enforces access control policies for traffic filtering.|
|Auto-Scaling and Traffic Throttling in OpenShift|Implement traffic throttling and auto-scaling in OpenShift to protect against denial-of-service (DoS) attacks.|SC-5 (Denial of Service Protection): Ensures systems can mitigate the impact of denial-of-service attacks by scaling resources and limiting traffic.|

**Section F:**

**Ensuring Compliance with NIST SP 800-53 Controls**
  
|**NIST SP 800-53 Control**|**Security Requirement**|**How Compliance is Assured**|
|---|---|---|
|IA-2 (Identification and Authentication)|Multi-Factor Authentication (MFA)|Enforce MFA through GitHub Enterprise’s built-in MFA features. Conduct regular audits to ensure all user accounts are MFA-enabled. Ensure MFA is configured during account setup and enforced at every login attempt.|
|AC-2 (Account Management)|OAuth 2.0 for Authentication, Granular Permissions for GitHub App, OAuth-Based API Access|Use GitHub’s OAuth-based authentication for account access. Set up role-based permissions for GitHub Apps and API access using OAuth tokens. Monitor access logs to ensure only authorized users or apps have access.|
|AC-3 (Access Enforcement)|Role-Based Access Control (RBAC)|Implement Role-Based Access Control (RBAC) in GitHub Enterprise and Node.js app. Regularly review and audit access permissions to ensure roles reflect least privilege.|
|AC-6 (Least Privilege)|Least Privilege Principle|Configure permissions based on the least privilege principle. Automate access provisioning workflows to ensure roles are assigned with minimum privileges. Conduct periodic access reviews to adjust privileges based on current roles and responsibilities.|
|SC-8 (Transmission Confidentiality and Integrity)|HTTPS (SSL/TLS) for All Communications|Ensure all communications between the user, Node.js app, and GitHub Enterprise use SSL/TLS encryption. Conduct regular vulnerability assessments to check for any misconfigurations in SSL/TLS.|
|SC-12 (Cryptographic Key Establishment and Management)|Mutual TLS (mTLS)|Use a secure key management solution for TLS certificate lifecycle management. Implement certificate management tools to track, renew, and revoke certificates as needed.|
|SI-7 (Software, Firmware, and Information Integrity)|Signed Commits in GitHub|Require all commits to repositories to be signed using GPG keys. Conduct periodic reviews of GitHub commit histories to ensure compliance with signed commit policies.|
|CM-5 (Access Restrictions for Configuration Changes)|Branch Protection Rules|Implement branch protection rules in GitHub repositories. Ensure that configuration changes can only be made by authorized users after code reviews.|
|SI-10 (Information Input Validation)|Input Validation|Implement input validation controls in the Node.js app to prevent injection attacks. Conduct regular security testing, including penetration testing and fuzzing, to ensure that input validation controls are effective.|
|SC-5 (Denial of Service Protection)|API Rate Limiting, Auto-Scaling and Traffic Throttling in OpenShift|Set up API rate limiting on GitHub API endpoints and Node.js app. Monitor system usage to detect and block potential DoS attacks. Configure auto-scaling in OpenShift to handle traffic surges and mitigate DoS risks.|
|IA-5 (Authenticator Management)|Token Expiry and Refresh|Enforce short token lifetimes and require regular token refreshes. Use secure storage for OAuth tokens to prevent token leakage. Audit token access logs to ensure tokens are used appropriately and are regularly rotated.|
|AU-6 (Audit Monitoring, Analysis, and Reporting)|Centralized Logging|Implement centralized logging solutions (e.g., ELK stack) for monitoring security events in both the Node.js app and GitHub Enterprise. Conduct continuous log analysis to detect anomalies or security incidents.|
|AU-9 (Protection of Audit Information)|Immutable Logs|Ensure that logs are stored in an immutable format (e.g., append-only storage). Use tamper-evident storage solutions to prevent alteration of audit logs. Monitor access to audit logs and ensure that only authorized users can view them.|
|AU-12 (Audit Generation)|GitHub Audit Logs|Enable audit logging in GitHub Enterprise and review logs periodically. Ensure logs capture all critical events, including repository access, pull requests, merges, and changes in permissions.|
|CA-7 (Continuous Monitoring)|Event Monitoring and Alerts|Set up continuous monitoring using security information and event management (SIEM) tools. Configure automated alerts for unusual activities, including access pattern anomalies and unauthorized changes in GitHub repositories.|
|SC-13 (Cryptographic Protection)|Encryption of Sensitive Data|Ensure all sensitive data in transit and at rest is encrypted using strong encryption protocols (AES-256, TLS 1.2+). Conduct regular encryption key rotation and review policies for encryption strength.|
|IR-4 (Incident Handling)|Incident Detection and Response Plan|Create a formal incident response plan. Conduct regular tabletop exercises and simulations to ensure the incident response team is prepared. Document and review all incidents, tracking resolution times and lessons learned for future improvement.|
|CP-9 (Information System Backup)|Data Backup and Recovery|Implement automated backups of GitHub repositories and system configurations. Conduct regular disaster recovery tests to ensure backups are functional and can be restored in a timely manner.|
|SC-7 (Boundary Protection)|Network Segmentation, Firewall and Security Groups|Implement firewall rules and network segmentation between critical systems (e.g., between the OCP-NODE and SUBNET-4). Regularly audit firewall rules to ensure they are effective and up to date.|
