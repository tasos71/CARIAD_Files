#!/bin/bash

# Install OpenSCAP and CIS benchmark content
sudo apt-get install -y libopenscap8
sudo wget https://security-metadata.canonical.com/oval/com.ubuntu.$(lsb_release -cs).usn.oval.xml.bz2
sudo bunzip2 com.ubuntu.$(lsb_release -cs).usn.oval.xml.bz2
for script in /tmp/script_*.sh; do sudo chmod +x $script; done

# Run OpenSCAP scan
sudo oscap oval eval --force --report before-report.html com.ubuntu.$(lsb_release -cs).usn.oval.xml

# Apply CIS Level 1 Workstation benchmark hardening
# (Assuming you have a script or tool to apply the hardening)

# Run OpenSCAP scan again
sudo oscap oval eval --force --report after-report.html com.ubuntu.$(lsb_release -cs).usn.oval.xml

# Generate a report with only the failed tests
sudo oscap oval eval --force --results after-results.xml com.ubuntu.$(lsb_release -cs).usn.oval.xml
sudo oscap xccdf generate report --output failed-report.html --results after-results.xml --profile xccdf_org.ssgproject.content_profile_cis

# Clean up
sudo rm com.ubuntu.$(lsb_release -cs).usn.oval.xml
