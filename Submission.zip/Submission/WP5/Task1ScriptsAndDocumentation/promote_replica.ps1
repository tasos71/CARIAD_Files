# Check the status of the primary server
.\Task1Script\check_primary_status.ps1
if ($LASTEXITCODE -eq 0) {
    Write-Output "Primary server is healthy. No need to promote replica."
    exit 0
}

# Promote the replica to primary
try {
    # promote replica
    ghe-repl-promote
    if ($LASTEXITCODE -ne 0) {
        Write-Output "Failed to promote replica to primary."
        exit 1
    }
    Write-Output "Replica promoted to primary."
} catch {
    Write-Output "An error occurred during promotion: $_"
    exit 1
}

# Verify promotion
try {
    $promotionStatus = ghe-repl-status
    if ($promotionStatus -notmatch "primary") {
        Write-Output "Promotion verification failed. Replica is not primary."
        exit 1
    }
    Write-Output "Promotion completed successfully."
} catch {
    Write-Output "An error occurred during promotion verification: $_"
    exit 1
}
