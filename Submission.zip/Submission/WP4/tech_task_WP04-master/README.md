# Tech Task WP04 - Monitoring

- [Tech Task WP04 - Monitoring](#tech-task-wp04---monitoring)
- [Prerequisites](#prerequisites)
  - [Bootstrap Azure Environment](#bootstrap-azure-environment)
    - [Initiate storage bucket to store the terraform state file and configure later as backend](#initiate-storage-bucket-to-store-the-terraform-state-file-and-configure-later-as-backend)
    - [Run Deployment on Azure and Grafana Managed](#run-deployment-on-azure-and-grafana-managed)
  - [Tasks](#tasks)
  - [01 Task - VM Monitoring:](#01-task---vm-monitoring)
    - [Oversee 6 virtual machines (VMs) in Azure by tracking system metrics and logs.](#oversee-6-virtual-machines-vms-in-azure-by-tracking-system-metrics-and-logs)
    - [Ensure metrics are pushed from the monitoring system to Grafana.](#ensure-metrics-are-pushed-from-the-monitoring-system-to-grafana)
    - [Create and maintain Grafana dashboards to visualize these metrics.](#create-and-maintain-grafana-dashboards-to-visualize-these-metrics)
    - [Set up alerts in Grafana for standard system metrics including CPU usage,](#set-up-alerts-in-grafana-for-standard-system-metrics-including-cpu-usage)
    - [HDD space, and RAM utilization.](#hdd-space-and-ram-utilization)
  - [02 Task - Web Endpoint Monitoring:](#02-task---web-endpoint-monitoring)
    - [Monitor the availability of 2-3 web endpoints.](#monitor-the-availability-of-2-3-web-endpoints)
    - [Check the HTTPS status and certificate validity of these endpoints using Grafana](#check-the-https-status-and-certificate-validity-of-these-endpoints-using-grafana)
  - [03 Task - Network Performance Monitoring:](#03-task---network-performance-monitoring)
    - [Develop a concept for continuously measuring the upload and download speeds of a simple file web service](#develop-a-concept-for-continuously-measuring-the-upload-and-download-speeds-of-a-simple-file-web-service)
  - [04 Task - Deployment and Configuration:](#04-task---deployment-and-configuration)
    - [Write and maintain the necessary code for deploying and configuring the monitoring systems in Azure using Terraform and Ansible.](#write-and-maintain-the-necessary-code-for-deploying-and-configuring-the-monitoring-systems-in-azure-using-terraform-and-ansible)
    - [Ensure the deployment scripts are well-documented and easy to execute.](#ensure-the-deployment-scripts-are-well-documented-and-easy-to-execute)


# Prerequisites
Ensure the following are available before deployment: 
- Access to the Azure cloud environment. 
- Installed and configured automation tools (Terraform). 
### Bootstrap Azure Environment
 Initiate storage bucket to store the terraform state file and configure later as backend
```bash
cd ../cloud-landing-zone/azure/bootstrap
terraform init
terraform fmt -diff
terraform validate
terraform plan
terraform apply
```

### Run Deployment on Azure and Grafana Managed
```bash
cd ../cloud-landing-zone/azure
terraform init
terraform fmt -diff
terraform validate
terraform plan
terraform apply
```

## Tasks
## 01 Task - VM Monitoring:
- Oversee 6 virtual machines (VMs) in Azure by tracking system metrics and logs.
- Ensure metrics are pushed from the monitoring system to Grafana.
- Create and maintain Grafana dashboards to visualize these metrics.
- Set up alerts in Grafana for standard system metrics including CPU usage, HDD space, and RAM utilization.

Using predefined Terraform templates, provision VMs with the necessary networking and compute configurations. Each VM will have Nginx installed. 
Terraform scripts deploy Grafana Managed, Prometheus Managed, set up Azure Analytics and Azure Monitor workspaces, and configure Azure Application Insights. Synthetic tests will be created to monitor endpoints availability and SSL certificates validity. 
Grafana connects to Azure Monitor through a Managed Identity, simplifying authentication and access control. To connect it, go to Connections -> Data Sources -> Azure Monitor. 

High-level architecture design:
![WP04 - Architecture](https://github.com/user-attachments/assets/aad8bd86-687f-43ed-ab66-5b7a7d196e0c)


Custom dashboards are configured in Grafana to display key performance metrics such as CPU utilization, disk space usage, available RAM, and network traffic. 

**Key Metrics Monitored:**

- CPU utilization 
- Disk usage (HDD) 
- Available RAM 
- Logs

<img width="1277" alt="VM Monitoring P1" src="https://github.com/user-attachments/assets/745251ff-b2af-4d8c-8f04-2db8381f4490">
<img width="1279" alt="VM Monitoring P2" src="https://github.com/user-attachments/assets/a29a3605-de41-4288-975c-afde133c14e4">
<img width="1279" alt="VM Monitoring P3" src="https://github.com/user-attachments/assets/dcb95ef5-d51e-459f-b0e7-4abd3650629d">


Metrics from Azure Application Insights and Azure Log Analytics are collected by Azure Monitor and sent to Grafana. Grafana acts as a single visualization tool, aggregating data from Azure monitoring tools and enabling alert configuration based on specific performance metrics. 


**Alert Configuration**

Based on best practices, following alert conditions were chosen:
- CPU Utilization: 
Alerts are triggered when CPU usage exceeds 60%. 
- Available RAM: 
An alert is triggered when available memory falls below 30%. 
- Disk Space: 
Alerts are generated when available HDD space reaches a predefined threshold. 

All alerts are configured to notify the Operations team through pre-defined policies. Configuartion of policies is attached in this archive.

<img width="1279" alt="VM Monitoring Alerts" src="https://github.com/user-attachments/assets/d94de48e-8b17-4776-9dd8-6bb716460b4e">


## 02 Task - Web Endpoint Monitoring: 
- Monitor the availability of 2-3 web endpoints.
- Check the HTTPS status and certificate validity of these endpoints using Grafana

Azure Application Insights performs availability checks and SSL certificate validation for two public endpoints: Cariad Technology and Accenture websites.

> Note: Since Grafana Synthetic Monitoring is available only for Grafana Cloud, it is replaced with Azure Application Insights in this solution to monitor the availability and SSL status of selected web endpoints. Via integration with Azure Monitor all relevant metrics are visible in Grafana. 

**Key Monitoring Visualizations** 
- Availability of endpoints
- HTTP status
- Certificates validity

<img width="1279" alt="Endpoint Monitoring Dashboard" src="https://github.com/user-attachments/assets/869246e0-3f85-401a-a62d-ab18e1de3a3d">

Following alerts are configured:

<img width="1278" alt="Endpoint Monitoring Alerts" src="https://github.com/user-attachments/assets/c08de9e5-6297-4a39-bae7-4c7ffbde9e7d">

Besides alerts, the report on availability of endpoints is created with following configuration. Report is sent as PDF attachement via email:
<img width="1278" alt="Availability report" src="https://github.com/user-attachments/assets/794175a3-9603-4938-9d2d-f7eff3fddb42">


## 03 Task - Network Performance Monitoring:
- Concept for continuously measuring the upload and download speeds of a simple file web service

To measure and visualize network performance, the following setup is recommended:
1. **Create a Web Service Endpoint.**
    Deploy a web service that is accessible and capable of handling file uploads and downloads. It should have endpoints like:
    - POST /upload (for uploading files)
    - GET /download (for downloading files)
2. **Create a Measurement Script.**
Develop a Python script that performs HTTP requests. The script will do the following tasks:
    - Measure upload speed
    - Measure download speed
    - Push the metrics to Azure Monitor

3. **Scheduling the Script.**
Use Azure Functions or Azure Logic Apps to run the above script periodically. Alternatively, the script can be scheduled on a local server or VM using cron jobs.

**Visualizing Metrics in Grafana**
1. **Set Up Grafana.**
Add Azure Monitor as a data source.
2. **Create a Dashboard.**
Create a new dashboard in Grafana.
Add panels to visualize:
    1.	Upload Speed
    2.	Download Speed
Use the following queries in Grafana to display the metrics:
- For Upload Speed:
    ```sh
    AzureMetrics
    | where Resource == "your_resource_name" 
    | where Name == "WebServiceUploadSpeed"
    | summarize avg(Total) by bin(Timestamp, 1m)
    ```
- For Download Speed:
    ```sh
    AzureMetrics
    | where Resource == "your_resource_name" 
    | where Name == "WebServiceDownloadSpeed"
    | summarize avg(Total) by bin(Timestamp, 1m)
    ```
3. **Setting Up Alerts.**
Configure alerts in Azure Monitor based on the upload and download speed thresholds. 

**Additional Checklist**
1. **Environment Check.**
Ensure that all required Azure packages are installed by running
    ```sh
    pip list
    pip install azure-monitor-opentelemetry azure-identity azure-mgmt-monitor requests
    ```
2. **Correct Imports.**
Ensure the Metrics Client is properly imported: For example, the Metrics Client should be from azure.monitor:
    ```sh
    from azure.monitor import MetricsClient
    ```
`from azure.monitor import MetricsClient`

Refer the [Azure SDK for Python documentation](https://docs.microsoft.com/en-us/python/api/overview/azure/monitor?view=azure-python) for the most up-to-date information regarding module usage and any breaking changes.


## 04 Task - Deployment and Configuration:
- Write and maintain the necessary code for deploying and configuring the monitoring systems in Azure using Terraform and Ansible.
- Ensure the deployment scripts are well-documented and easy to execute.

All automation scripts are modular, facilitating easy updates and maintenance. Each script is dedicated to a specific task, such as VM provisioning or monitoring configuration. Below is a breakdown of all Terraform scripts used in the deployment process.

**Terraform File Structure**

**grafana.tf**
The grafana.tf file content defines Grafana provided to restore Grafana dashboards from JSON files.


Under Azure folder:

**locals.tf**

The locals.tf file defines local variables for resource management in Terraform:
- resource_lowercase_array: Creates an array with the lowercase version of var.environment.
- resource_suffix_uppercase: Joins the lowercase array into a hyphenated string (though the result will still be lowercase).
- resource_suffix_lowercase: Joins the lowercase array into a single lowercase string without separators.
- users_identities: Defines a list of user Object IDs for access control.
- tags: Merges existing tags with new tags for "Creator" and "Environment," creating a comprehensive tagging structure.

**loganalytics.tf**

The loganalytics.tf file content defines a Terraform resource for creating an Azure Log Analytics workspace. Here's a brief overview:
- resource "azurerm_log_analytics_workspace" "default": This specifies the resource type and its name in Terraform.
- name: Sets the name of the Log Analytics workspace using a formatted string that includes a prefix "log-" followed by the uppercase suffix from the local.resource_suffix_uppercase variable.
- location: Assigns the location for the workspace based on the location of an existing Azure resource group defined as azurerm_resource_group.rg.
- resource_group_name: Specifies the name of the resource group where the workspace will be created, again referencing azurerm_resource_group.rg.
- sku: Sets the pricing tier for the workspace to "PerGB2018."
- retention_in_days: Configures the data retention period for the logs to 30 days.

**main.tf**

This configuration automates the setup of a scalable Azure environment, including networking, compute resources, and monitoring capabilities, aimed at ensuring high availability and observability of the deployed VMs.

**observability.tf**

The observability.tf file provisions observability resources, focused on integrating Grafana for metrics collection and visualization.
Grafana Dashboard: Creates a Grafana instance named "amg-tech-wp04" for visualizing metrics, with public access enabled and system-assigned identity for authentication.

**outputs.tf**

The outputs.tf file defines several output values in Terraform that are useful for referencing key information after the infrastructure has been provisioned:
- resource_group_name: Outputs the name of the Azure resource group created, making it easily accessible.
- virtual_network_name: Outputs the name of the virtual network that was created, allowing users to quickly reference it.
- subnet_name: Outputs the name of the subnet that was created, providing quick access to this resource.
- linux_virtual_machine_names: Outputs a list of names for all Linux virtual machines created, using a for loop to gather their names into an array.
- grafana_url: Outputs the endpoint URL of the 

**providers.tf**

The providers.tf file configures the Terraform environment by specifying backend storage and defining the required providers.
- Sets the backend to Azure Resource Manager (azurerm) for storing the Terraform state file.
- Specifies the Azure subscription ID, resource group, storage account, container name, and the key for the state file.
- Configures the azurerm provider, enabling features and specifying the subscription ID.
- Configures the azuread provider, setting the tenant ID based on the current Azure client configuration.
- azurerm: Specifies the Azure Resource Manager provider with version 4.2.0.
- azapi: Specifies the Azure API provider with version 2.0.0-beta.
- random: Specifies the Random provider with a version constraint of ~>3.0.#
- Registers the Microsoft.Monitor resource provider in Azure, which is necessary for monitoring resources.

**roles.tf**

The roles.tf file defines several role assignments for users in Azure, specifically for managing access to Grafana and monitoring resources within a specified resource group.
- Assigns the "Grafana Viewer," "Grafana Editor," and "Monitoring Reader" roles to each user identity listed in local.users_identities, scoped to the specified Azure resource group. This allows those users to view, edit, and read monitoring data related to Grafana, respectively.
- Conditional assignments for the "Grafana Viewer," "Grafana Editor," and "Monitoring Reader" roles are made to the shared identity of the Grafana dashboard. This grants the Grafana instance permissions based on its identity.
- Assigns the "Grafana Admin" role to each user identity in local.users_identities, allowing those users to have administrative privileges in Grafana.

**ssh.tf**

The ssh.tf file is responsible for generating and managing SSH key pairs for secure access to Azure resources.
- The random_pet resource generates a unique name for the SSH key, using "ssh" as a prefix and an empty string as a separator. This ensures that the SSH key has a distinctive name.
- The azapi_resource_action resource initiates the generation of an SSH public/private key pair in Azure. It specifies the resource type, the resource ID where the key will be created, and uses a POST method to request the key pair generation. The generated public and private keys are exported for later use.
- The azapi_resource resource creates the actual SSH public key in Azure, associating it with the specified resource group and using the randomly generated name.
- An output variable named key_data is defined to return the generated public key, making it accessible for use in other configurations or outputs.

**sslsynthetic.tf**

This Terraform code configures an Azure Application Insights resource along with two web tests to monitor the SSL status of two different websites (https://cariad.technology and https://www.accenture.com).
- Creates an Azure Application Insights instance named testsslmonitor for web application monitoring.
- Sets up a web test named testsslmonitor-cariad to monitor the URL https://cariad.technology.
- Validates that the site returns a 200-status code and checks the SSL certificate's remaining lifetime (minimum of 7 days).
- Configures a similar web test named testsslmonitor-acn for https://www.accenture.com with the same validation rules.

**template-terraform.tfvars**
This file is used to set up variabled for connection to Azure resourcs: Subscription ID, Admin Group Object ID, and Tenant ID.

**variables.tf**

The variables.tf file defines various input variables used in the Terraform configuration.
- Subscription ID: Azure subscription ID.
- Resource Group Location: Default is "eastus".
- Resource Group Name Prefix: Unique prefix for resource group names.
- Username: Local VM account username, default "azureadmin".
- Grafana Admin Object ID: ID for the Grafana Admin role.
- Grafana Major Version: Default is "10".
- Public Network Access: Enables/disables public access for Grafana, default true.
- API Key Enabled: Controls API key authentication, default false.
- Grafana Auth Token: Token for Grafana authentication.
- Diagnostic Setting Name: Name for monitoring settings.
- Enabled Log Categories: Default includes "GrafanaLoginEvents".
- Enabled Metric Categories: Initially empty list.
- Environment: Deployment environment with validation (dev/stag/prod).
- Creator: Project creator name, default "terraform".
- Tags: Custom tags for resources.
- Monitoring Enabled: Enables monitoring for Grafana, default true.
- Prometheus Grafana Configuration: Object for settings related to Grafana.

Under Bootstrap folder: 

**main.tf**

The main.tf file sets up an Azure backend for Terraform by:
- Creating a Resource Group named rg-backend-azure-tf with an environment tag.
- Creating a Storage Account named tfbackendtechwp18924 in the resource group, configured for Standard tier and LRS replication, also tagged with environment.
- Creating a Storage Container named terraform-state in the storage account with private access, for secure storage of Terraform state files.


**providers.tf**

The providers.tf file specifies the Terraform providers used in the configuration
- Specifies the required providers for the configuration, particularly the Azure Resource Manager (azurerm) provider, version 4.2.0, sourced from HashiCorp.
- Configures the azurerm provider, including enabling its features and setting the Azure subscription ID.
- Retrieves the current Azure client configuration using azurerm_client_config, which provides details about the authenticated user's context.

Under scripts folder: 

**init.sh**
The init.sh file installs ngingx on virtual machines.

Under Grafana folder Grafana dashboards, alert configurations with defined policies are stored. 
