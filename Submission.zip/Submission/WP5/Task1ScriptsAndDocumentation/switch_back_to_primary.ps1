# Get the IP addresses from environment variables
$originalPrimaryServerIp = $env:PRIMARY_SERVER_IP
$currentPrimaryServerIp = $env:REPLICA_SERVER_IP

# Check the status of the original primary server
if (-not (Test-Connection -ComputerName $originalPrimaryServerIp -Count 3 -Quiet)) {
    Write-Output "Original primary server is still down"
    exit 0  # Exit with code 0 to indicate success in GitHub Actions
}

# Demote the current primary (which was the replica)
try {
    ghe-repl-teardown
    if ($LASTEXITCODE -ne 0) {
        Write-Output "Failed to demote the current primary."
        exit 1
    }
    Write-Output "Current primary demoted successfully."
} catch {
    Write-Output "An error occurred during demotion: $_"
    exit 1
}

# Promote the original primary back to primary
try {
    ghe-repl-promote
    if ($LASTEXITCODE -ne 0) {
        Write-Output "Failed to promote the original primary."
        exit 1
    }
    Write-Output "Original primary promoted successfully."
} catch {
    Write-Output "An error occurred during promotion: $_"
    exit 1
}

# Verify promotion
try {
    $promotionStatus = ghe-repl-status
    if ($promotionStatus -notmatch "primary") {
        Write-Output "Promotion verification failed. Original primary is not primary."
        exit 1
    }
    Write-Output "Promotion completed successfully."
} catch {
    Write-Output "An error occurred during promotion verification: $_"
    exit 1
}

Write-Output "Switched back to the original primary."
