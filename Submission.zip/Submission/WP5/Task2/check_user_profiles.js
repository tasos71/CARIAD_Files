const { Octokit } = require("@octokit/rest");
const octokit = new Octokit({ auth: process.env.GITHUB_TOKEN });

const whitelistedDomains = process.env.WHITELISTED_DOMAINS.split(',');

async function checkUserProfiles() {
  try {
    const { data: users } = await octokit.paginate(octokit.users.list, {
      per_page: 100,
    });

    let logSummary = '';
    users.forEach(user => {
      if (user.email && !isWhitelisted(user.email)) {
        logSummary += `User: ${user.login}, Email: ${user.email}\n`;
        console.log(`\x1b[31mUser: ${user.login}, Email: ${user.email}\x1b[0m`); // Red colored output
      }
    });

    if (logSummary) {
      console.log('Summary of users with non-compliant emails:\n' + logSummary);
    } else {
      console.log('All user profiles are compliant.');
    }
  } catch (error) {
    console.error('Error checking user profiles:', error);
  }
}

function isWhitelisted(email) {
  const domain = email.split('@')[1];
  return whitelistedDomains.includes(domain);
}

checkUserProfiles();
