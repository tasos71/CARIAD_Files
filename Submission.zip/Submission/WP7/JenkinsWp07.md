## Tasks: 1. Create a Jenkins Instance with Dummy Jobs on Kubernetes {#tasks-1.-create-a-jenkins-instance-with-dummy-jobs-on-kubernetes .unnumbered}

###  • Set up an AKS cluster in Azure.  {#set-up-an-aks-cluster-in-azure. .unnumbered}

### • Deploy a Jenkins instance on the AKS cluster. {#deploy-a-jenkins-instance-on-the-aks-cluster. .unnumbered}

1)  Install Azure Cli

[Install the Azure CLI for Windows \| Microsoft
Learn](https://learn.microsoft.com/en-us/cli/azure/install-azure-cli-windows?tabs=azure-cli)

2)  Install Terraform

<https://developer.hashicorp.com/terraform/install>

3)  Create all required .tf files.

  -----------------------------------------------------------------------
  az login \--tenant 92587c31-827a-4b7d-870a-f29c9f9103
  -----------------------------------------------------------------------

  -----------------------------------------------------------------------

4)  Run

+-----------------------------------------------------------------------+
| terraform init                                                        |
|                                                                       |
| terraform plan                                                        |
|                                                                       |
| az aks get-credentials \--resource-group tech_task-WP07_Jenkins       |
| \--name wp07-cluster                                                  |
|                                                                       |
| terraform apply                                                       |
+=======================================================================+
+-----------------------------------------------------------------------+

### • Create several dummy jobs in Jenkins to simulate a real environment. {#create-several-dummy-jobs-in-jenkins-to-simulate-a-real-environment. .unnumbered}

1)  Run

+-----------------------------------------------------------------------+
| kubectl get secret jenkins -n wp07 -o                                 |
| jsonpath=\'{.data.jenkins-admin-password}\' \| base64 \--decode       |
|                                                                       |
| mgdKtGkoLxEB2C1X97rCRA                                                |
+=======================================================================+
+-----------------------------------------------------------------------+

2)  Login to Jenkins using externalIp of the service Jenkins and use the
    credentials find in the secret

<http://57.152.53.115:8080/>

![](./images/media/image1.png){width="6.156978346456693in"
height="3.1368536745406823in"}

3)  Create dummy jobs

![A screenshot of a computer Description automatically
generated](./images/media/image2.png){width="7.307717629046369in"
height="3.425738188976378in"}

## Task 2. Backup the Instance and Validate the Backup  {#task-2.-backup-the-instance-and-validate-the-backup .unnumbered}

Important Points to consider:

-   **Never include the controller key in your Jenkins backup!**

### • Implement a backup strategy for the Jenkins instance.  {#implement-a-backup-strategy-for-the-jenkins-instance. .unnumbered}

1)  Installed Thinbackup Plugin from manageJenkins -\> plugin

2)  Configure the Backup strategy in ManageJenkins - \> **system**

![](./images/media/image3.png){width="6.3in"
height="2.6618055555555555in"}

### Validate that the backup is complete and can be restored successfully

1)  Create a backup in ThinBackup

![A screenshot of a computer Description automatically
generated](./images/media/image4.png){width="7.1825656167979in"
height="2.8542344706911638in"}

2)  Once backup is done delete one job e.g. DemoJob-1

![A screenshot of a computer Description automatically
generated](./images/media/image5.png){width="6.728332239720035in"
height="3.678153980752406in"}

3)  Stop the Jenkins Pod.

  -----------------------------------------------------------------------
  kubectl delete pod/jenkins-0 -n wp07
  -----------------------------------------------------------------------

  -----------------------------------------------------------------------

4)  Once the pod restart, login to Jenkins again go to Periodic Backup
    Manager and Restore from the backup.

![A screenshot of a computer Description automatically
generated](./images/media/image6.png){width="6.058465660542432in"
height="2.5204297900262467in"}

5)  Restart the pod again

![A screenshot of a computer Description automatically
generated](./images/media/image7.png){width="7.3753674540682415in"
height="3.6177646544181976in"}

## 3. Security Breach Scenario: Master Key Exposure  {#security-breach-scenario-master-key-exposure .unnumbered}

### Make the Instance Unavailable to Others o Scale down the Jenkins deployment to zero replicas.  {#make-the-instance-unavailable-to-others-o-scale-down-the-jenkins-deployment-to-zero-replicas. .unnumbered}

1)  Make the service unavailable

  -----------------------------------------------------------------------
  kubectl scale statefulsets jenkins \--replicas=0 -n wp07
  -----------------------------------------------------------------------

  -----------------------------------------------------------------------

### Rotate the Master Key  {#rotate-the-master-key .unnumbered}

####  Generate a new master key for Jenkins {#generate-a-new-master-key-for-jenkins .unnumbered}

1)  Run the below command

  -----------------------------------------------------------------------
  openssl rand -base64 256
  -----------------------------------------------------------------------

  -----------------------------------------------------------------------

> **New Master key**

#### vt5a1I0TQmKCwq+EQM5lOOxmWPKjMsF0cUToRNe7eDF63DAqO8cn1FvkFxerFzPz {#vt5a1i0tqmkcwqeqm5looxmwpkjmsf0cutorne7edf63daqo8cn1fvkfxerfzpz .unnumbered}

#### gO3SVooWb9AVwgyIb14YpaDD7AwrX66H4tkh7jvzVaf1LeutyJHTRSbVwCUYYyjZ {#go3svoowb9avwgyib14ypadd7awrx66h4tkh7jvzvaf1leutyjhtrsbvwcuyyyjz .unnumbered}

#### vwn7bZbYF9lZoC+a9mX2PUXi5UTMcKhrTNloWNKcMCGFqnvdi7w55W0LcQUejZMW {#vwn7bzbyf9lzoca9mx2puxi5utmckhrtnlownkcmcgfqnvdi7w55w0lcquejzmw .unnumbered}

#### jjfslyMuWDY59AcNBLxr6vhR3h55mYVsGrhv8apmnuPfKFBCJcYeqro6luwxuDkW {#jjfslymuwdy59acnblxr6vhr3h55myvsgrhv8apmnupfkfbcjcyeqro6luwxudkw .unnumbered}

#### jIdD8fHcg8tsx00wfURVBwFQgzXIYT40dZCWY2hZW81PNcNo4URHO8tT3AcxGNV6 {#jidd8fhcg8tsx00wfurvbwfqgzxiyt40dzcwy2hzw81pncno4urho8tt3acxgnv6 .unnumbered}

#### sDb+xQBCdn91a7xeZIgNow== {#sdbxqbcdn91a7xezignow .unnumbered}

#### Update the Jenkins configuration with the new master key {#update-the-jenkins-configuration-with-the-new-master-key .unnumbered}

1)  Scale up the Deployment again

  -----------------------------------------------------------------------
  kubectl scale statefulsets jenkins \--replicas=1 -n wp07
  -----------------------------------------------------------------------

  -----------------------------------------------------------------------

**Old Master key**

  -----------------------------------------------------------------------
  kubectl exec pod/jenkins-0 -n wp07 \-- cat
  /var/jenkins_home/secrets/master.key
  -----------------------------------------------------------------------

  -----------------------------------------------------------------------

9e663a6b58a1a22ef8464cc9b3079a896de13739b47f0532513aa56f4b922ca016386cacaef0c8dd1566efc8c35df89f51c77e4b2b180944b7ca4459d495c866d1110c87367bf496bdd44d2284c6853b0db82da8d51863c6dc5c219a16956616456dc51a44eba1d7da7cecbb45e93fb770d9ef7e2098aa2d025b6041ce985f0

2)  Generate backup for master key

  -----------------------------------------------------------------------
  kubectl exec pod/jenkins-0 -n wp07\-- cp
  /var/jenkins_home/secrets/master.key
  /var/jenkins_home/secrets/master20092024.key
  -----------------------------------------------------------------------

  -----------------------------------------------------------------------

3)  Update master key

+-----------------------------------------------------------------------+
| #### kubectl exec pod/jenkins-0 -n wp07 \--                           |
| sh -c \'echo \" vt5a1I0TQmKCwq+EQM5lOOxmWPKjMsF0cUToRNe7eDF63DAqO8cn1 |
| FvkFxerFzPz {#kubectl-exec-podjenkins-0--n-wp07----sh--c-echo-vt5a1i0 |
| tqmkcwqeqm5looxmwpkjmsf0cutorne7edf63daqo8cn1fvkfxerfzpz .unnumbered} |
|                                                                       |
| #### gO3SVooW                                                         |
| b9AVwgyIb14YpaDD7AwrX66H4tkh7jvzVaf1LeutyJHTRSbVwCUYYyjZ {#go3svoowb9 |
| avwgyib14ypadd7awrx66h4tkh7jvzvaf1leutyjhtrsbvwcuyyyjz-1 .unnumbered} |
|                                                                       |
| #### vwn7bZb                                                          |
| YF9lZoC+a9mX2PUXi5UTMcKhrTNloWNKcMCGFqnvdi7w55W0LcQUejZMW {#vwn7bzbyf |
| 9lzoca9mx2puxi5utmckhrtnlownkcmcgfqnvdi7w55w0lcquejzmw-1 .unnumbered} |
|                                                                       |
| #### jjfslyMu                                                         |
| WDY59AcNBLxr6vhR3h55mYVsGrhv8apmnuPfKFBCJcYeqro6luwxuDkW {#jjfslymuwd |
| y59acnblxr6vhr3h55myvsgrhv8apmnupfkfbcjcyeqro6luwxudkw-1 .unnumbered} |
|                                                                       |
| #### jIdD8fHc                                                         |
| g8tsx00wfURVBwFQgzXIYT40dZCWY2hZW81PNcNo4URHO8tT3AcxGNV6 {#jidd8fhcg8 |
| tsx00wfurvbwfqgzxiyt40dzcwy2hzw81pncno4urho8tt3acxgnv6-1 .unnumbered} |
|                                                                       |
| sDb+xQBCdn91a7xeZIgNow==                                              |
|                                                                       |
| \" \| tee /var/jenkins_home/secrets/master.key\'                      |
+=======================================================================+
+-----------------------------------------------------------------------+

4)  Restart the pod to update the Master Key

  -----------------------------------------------------------------------
  kubectl delete pod/jenkins-0 -n wp07
  -----------------------------------------------------------------------

  -----------------------------------------------------------------------

### Re-encrypt All Credentials {#re-encrypt-all-credentials .unnumbered}

####  Re-encrypt all stored credentials in Jenkins using the new master key {#re-encrypt-all-stored-credentials-in-jenkins-using-the-new-master-key .unnumbered}

1)  Jenkins automatically encyprt credentials with new master key upon
    restart as it detects the changes in master key.

### Make the Instance Available to Others  {#make-the-instance-available-to-others .unnumbered}

####  Scale the Jenkins deployment back up.  {#scale-the-jenkins-deployment-back-up. .unnumbered}

1)  As we just deleted the pod, the pod will be up again.

### Validate that the Jobs are Still Working  {#validate-that-the-jobs-are-still-working .unnumbered}

#### Ensure all dummy jobs are functioning correctly after the security changes. {#ensure-all-dummy-jobs-are-functioning-correctly-after-the-security-changes. .unnumbered}

1)  Login to Jenkins to check the jobs

![A screenshot of a computer Description automatically
generated](./images/media/image8.png){width="9.035554461942258in"
height="4.522831364829396in"}
